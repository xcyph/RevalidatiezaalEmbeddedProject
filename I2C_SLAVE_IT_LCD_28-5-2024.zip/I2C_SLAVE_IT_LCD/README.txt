*** Beschrijving ***
Upload naar STM32 met LCD. Luistert naar bericht van 1 char van RaspPi. Wanneer 'Y' ontvangen wordt, print HELLO WORLD naar LCD en stuur "A"
terug naar RaspPi. Daarna weer luisteren voor nieuw bericht.

*** Pin layout ***
RaspPi comm:
	PB7 (D4): I2C1_SDA
	PB6 (D5): I2C1_SCL
LCD:
	PB4 (D12): I2C3_SDA
	PA7 (A6): I2C3_SCL

*** Configuratie ***
Slave address I2C1: 0x10
liquidcrystal_i2c.c: ExpanderWrite(): &hi2c1 -> &hi2c3